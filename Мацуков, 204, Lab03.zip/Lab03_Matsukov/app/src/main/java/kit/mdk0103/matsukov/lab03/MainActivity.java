package kit.mdk0103.matsukov.lab03;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Calculate(View view) {
        EditText priceApple = findViewById(R.id.inputEditTextPriceApple);
        EditText priceStrawberry = findViewById(R.id.inputEditTextPriceStrawberry);
        EditText priceBlueberry = findViewById(R.id.inputEditTextPriceBlueberry);
        EditText pricePotatoes = findViewById(R.id.inputEditTextPricePotatoes);

        EditText inputApple = findViewById(R.id.inputEditTextApple);
        EditText inputStrawberry = findViewById(R.id.inputEditTextStrawberry);
        EditText inputBlueberry = findViewById(R.id.inputEditTextBlueberry);
        EditText inputPotatoes = findViewById(R.id.inputEditTextPotatoes);

        CheckBox checkBoxApple = findViewById(R.id.checkBoxApple);
        CheckBox checkBoxStrawberry = findViewById(R.id.checkBoxStrawberry);
        CheckBox checkBoxBlueBerry = findViewById(R.id.checkBoxBlueberry);
        CheckBox checkBoxPotatoes = findViewById(R.id.checkBoxPotato);

        RadioButton toast = findViewById(R.id.radioButtonToast);
        RadioButton dialog = findViewById(R.id.radioButtonDialog);

        int Result = 0;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Общая цена");
        builder.setMessage("Всего " + Result + "₽");
        builder.setCancelable(true);

        if (checkBoxApple.isChecked()) {
            Result += Integer.parseInt(inputApple.getText().toString()) * Integer.parseInt(priceApple.getText().toString());
        }
        if (checkBoxStrawberry.isChecked()) {
            Result += Integer.parseInt(inputStrawberry.getText().toString()) * Integer.parseInt(priceStrawberry.getText().toString());
        }
        if (checkBoxBlueBerry.isChecked()) {
            Result += Integer.parseInt(inputBlueberry.getText().toString()) * Integer.parseInt(priceBlueberry.getText().toString());
        }
        if (checkBoxPotatoes.isChecked()) {
            Result += Integer.parseInt(inputPotatoes.getText().toString()) * Integer.parseInt(pricePotatoes.getText().toString());
        }

        if (toast.isChecked()) {
            Toast.makeText(this, "Всего: " + Result + "₽", Toast.LENGTH_LONG).show();
        }
        if (dialog.isChecked()){
            builder.show();
        }
    }
}